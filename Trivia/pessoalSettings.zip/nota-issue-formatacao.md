# Nota — Alterações nos `.gitignore`

Os commits de configuração de formatação desta issue modificam o `.gitignore` do **backend** e do **frontend**.

A regra `.vscode/` (que ignorava a pasta inteira) foi substituída por `.vscode/*` com exceções explícitas para `extensions.json` e `settings.json`, permitindo que as configurações do VS Code sejam versionadas.

**Quem já tem o repositório clonado:** se o VS Code não reconhecer o `settings.json` imediatamente, rode `git rm -r --cached .vscode/` dentro do repo afetado e faça um novo `git pull`.
