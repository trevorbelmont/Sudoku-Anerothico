# Padronização de Formatação — SICAT

O projeto SICAT adota um conjunto de configurações de formatação versionadas nos repositórios `sicat-backend` e `sicat-frontend`, com o objetivo de uniformizar o estilo de código entre os desenvolvedores sem introduzir diffs massivos no histórico do legado. O ponto de partida conceitual é o Google Style Guide, adaptado às restrições do ecossistema corporativo Spring Boot e à verbosidade natural de anotações Java.

A formatação **não é aplicada automaticamente ao salvar** (`formatOnSave: false` globalmente). Isso é intencional: o SICAT possui código legado extenso e a ativação do auto-format polui o `git blame` e dificulta o code review ao misturar alterações funcionais com ajustes cosméticos. A formatação é aplicada sob demanda (`Shift+Alt+F`) ou em issues exclusivas de cleaning.

---

## Estrutura de Versionamento

As configurações são distribuídas entre os dois repositórios existentes — sem repositório externo adicional.

```
sicat/                          ← pasta local de trabalho (não versionada)
├── SICAT.code-workspace        ← copiado de sicat-backend/ (ver README do backend)
├── sicat-backend/
│   ├── .vscode/
│   │   ├── settings.json       ← configs do Java LS
│   │   └── extensions.json     ← extensões recomendadas do backend
│   └── eclipse-formatter.xml  ← profile do Java Formatter (120 col)
└── sicat-frontend/
    ├── .vscode/
    │   └── settings.json       ← configs do Prettier/Vue
    ├── .prettierrc.json        ← printWidth: 120
    └── .editorconfig           ← max_line_length: 120
```

O arquivo `SICAT.code-workspace` é o ponto de entrada recomendado. Ao abri-lo, o VS Code aplica as configurações de ambos os projetos em um único workspace multi-root e notifica o desenvolvedor para instalar as extensões recomendadas. Configurações puramente cosméticas (temas, minimap, fontes) não estão versionadas — pertencem ao `settings.json` global de cada desenvolvedor.

Os `.gitignore` de ambos os repositórios foram ajustados para versionar `settings.json` dentro de `.vscode/`, mantendo a exceção pré-existente para `extensions.json`.

---

## Backend (Java)

- **Formatter:** `redhat.java` (Language Server for Java — Red Hat)
- **Profile:** `SICAT-GoogleStyle-120`, definido em `eclipse-formatter.xml`
- **Limite de linha:** 120 colunas (`lineSplit` e `comment.line_length`)
- **Indentação:** 2 espaços (padrão Google Java Style)
- **Chaves:** K&R style (abertura na mesma linha)
- **`formatOnSave`:** desativado

O XML do formatter é referenciado via `java.format.settings.url` no `settings.json`. Quando o workspace é aberto via `.code-workspace`, o caminho é `sicat-backend/eclipse-formatter.xml`; quando o backend é aberto isoladamente, o caminho é `eclipse-formatter.xml`. Ambos os cenários estão cobertos pelas configs respectivas.

## Frontend (Vue / TypeScript)

- **Formatter:** `esbenp.prettier-vscode`
- **Limite de linha:** 120 colunas (`printWidth: 120` em `.prettierrc.json`)
- **Aspas:** simples (`singleQuote: true`)
- **Ponto e vírgula:** ausente (`semi: false`)
- **Indentação:** 2 espaços (padrão do ecossistema Node/Vue)
- **`formatOnSave`:** desativado

O `.editorconfig` está alinhado com o Prettier (`max_line_length: 120`) para IDEs que o consomem diretamente. O ESLint está configurado com `eslint-config-prettier` (`skipFormatting`), delegando inteiramente as decisões de estilo ao Prettier e evitando conflitos de regras.

---

## Réguas Visuais

Ambos os projetos exibem réguas em `[100, 120]`. A primeira (100) serve de aviso; a segunda (120) é o hard limit efetivo dos formatters. Essa configuração está presente tanto nos `settings.json` de cada repo quanto no `.code-workspace`.
