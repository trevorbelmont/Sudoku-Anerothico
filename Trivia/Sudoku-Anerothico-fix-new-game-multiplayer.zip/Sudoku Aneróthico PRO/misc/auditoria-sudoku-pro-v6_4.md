# Auditoria profunda de código — Sudoku Aneróthico PRÓ v6.4

**Data:** 29/10/2026  
**Escopo:** código-fonte presente no `sudoku-pro-v6_4.zip`, com foco em privacidade, segurança, integridade do jogo, concorrência multiplayer, robustez, desempenho e preparação para publicação web/Windows/Android.

## 1. Veredito executivo

**O projeto ainda não está pronto para publicação pública.** A interface e a divisão em arquivos são utilizáveis como base, mas o multiplayer atual não tem uma fronteira de confiança no servidor. O cliente Firebase grava diretamente os estados que definem a partida, a identidade do jogador é criada localmente e a solução completa do Sudoku é enviada a todos os clientes autorizados a ler os metadados da sala.

Os bloqueadores mais importantes são:

1. **Banco aberto:** se as regras do Firebase associado ao `projectId: sudoku-anerothico` realmente estão em modo de teste aberto, qualquer pessoa que alcance o banco pode ler, modificar ou apagar dados. Não coloque dados reais nem considere essa configuração aceitável para lançamento.
2. **Privacidade:** o objeto `clientMetadata` é gravado num registro lido por todos os clientes da sala, e esses registros persistem mesmo após a saída do jogador.
3. **Anti-cheat:** movimentos, votações, contribuições, estado de conclusão e criação de nova instância são decididos pelo cliente. Modificar JavaScript ou enviar gravações diretamente ao Realtime Database contorna as restrições da interface.
4. **Solução exposta:** `solutionGrid` é parte de `rooms/{roomId}/meta`; o código de compartilhamento também inclui a solução num payload Base64 facilmente decodificável.
5. **Validação de Sudoku insuficiente:** a validação de estado aceita soluções incompletas ou inválidas e a verificação de vitória não confere todos os invariantes do puzzle.
6. **Consistência multiplayer:** gravações de tabuleiro inteiro podem sobrescrever alterações de célula concorrentes; logs de movimentos crescem sem limite e são relidos/sortidos integralmente a cada evento.
7. **Falhas de robustez:** conteúdo remoto malformado pode derrubar callbacks de interface; códigos compartilhados e histórico local não passam por validação completa antes de serem aplicados.

A correção não é simplesmente “esconder” alguns campos e fechar as regras no fim. A estrutura de dados e o protocolo multiplayer precisam ser concebidos para funcionar com autenticação e autorização desde o começo.

## 2. Escopo, método e limites

A auditoria foi estática: leitura dos arquivos HTML, JavaScript e PowerShell incluídos no ZIP, busca por usos de armazenamento, DOM, Firebase, geração/importação de puzzles e caminhos multiplayer, além de verificação sintática dos arquivos JavaScript com `node --check`.

**Todos os arquivos JavaScript passaram na verificação sintática**, o que só demonstra que o parser não encontrou erros de sintaxe. Não significa que os fluxos funcionem corretamente.

Não recebi as regras atuais do Realtime Database, configurações de Authentication/App Check/hosting, logs reais, nem um pacote Windows/Android. Não rodei uma sessão completa com múltiplos navegadores nem fuzzing do banco implantado. Portanto:

- os problemas de lógica identificados no código podem ser apontados diretamente;
- os riscos de acesso remoto dependem das regras efetivamente implantadas e de quem pode gravar em cada caminho;
- a auditoria não é uma certificação de segurança nem prova de ausência de vulnerabilidades;
- o empacotamento nativo para Windows/Android exigirá uma revisão complementar.

## 3. Severidade usada

- **P0 — Crítico:** exposição imediata de dados/controle se a condição descrita estiver ativa. Bloqueia qualquer lançamento.
- **P1 — Alto:** permite quebra de privacidade, integridade ou confiança do jogo; precisa ser corrigido antes de publicar.
- **P2 — Médio:** inconsistência relevante, falha de robustez, concorrência ou abuso de recursos; corrigir antes do lançamento, salvo decisão explícita de escopo.
- **P3 — Baixo:** dívida técnica, degradação ou endurecimento recomendado.

---

## 4. Achados detalhados

### P0 — Regras do Firebase abertas permitem leitura, gravação e exclusão por terceiros

**Local:** `js/firebase-config.js:2-9`; cliente Firebase em `js/firebase-client.js:1-23`. As regras estão no Console/arquivo de configuração do Firebase e não vieram no ZIP.

A aplicação inicializa o Realtime Database diretamente no navegador, sem Firebase Authentication. Você informou que está usando o banco em modo de teste aberto. Se isso significa que `.read` e `.write` estão permitidos publicamente, as operações não estão protegidas por uma identidade confiável: qualquer pessoa que conheça o projeto pode tentar ler, alterar e excluir nós de salas.

**Impacto:** exposição de dados de salas, alteração/limpeza de tabuleiros, falsificação de presença e votos, adulteração de resultados, criação de dados em massa, consumo de quota e possível custo/indisponibilidade.

**Ações:**

1. Use o Firebase Emulator Suite ou um projeto de desenvolvimento descartável e sem dados reais enquanto as regras estiverem abertas.
2. Não publique a aplicação apontando para esse banco em modo aberto.
3. Implante regras de negação por padrão e abra somente operações estritamente necessárias, vinculadas a `auth.uid` e à participação na sala.
4. Não confie em regras apenas por formato: regras devem limitar quem lê e escreve, quais campos podem mudar, tipos, tamanhos e transições permitidas.
5. Teste as regras no emulador antes de associá-las ao ambiente de produção.

A configuração web (`apiKey`, `projectId`, `appId`) é naturalmente visível no cliente e **não deve ser tratada como senha**. A proteção vem das regras, autenticação, limites de serviço e arquitetura do backend — não de esconder esse objeto.

### P1 — Metadados de dispositivo são compartilhados com todos os participantes da sala

**Local:** `js/multiplayer-service.js:192-251`, `480-501` e `670-749`; aviso de privacidade em `index.html:853-855`.

`collectClientMetadata()` coleta navegador/versão, sistema operacional estimado/versão, plataforma, idioma, idiomas preferidos, fuso horário, dimensões da tela e viewport, profundidade de cor, densidade de pixels, status online e informações de conexão quando disponíveis. `registerRoomPresence()` grava isso em `rooms/{roomId}/members/{playerId}/clientMetadata`. O listener lê o nó completo `members`, não apenas os campos públicos de presença.

Os metadados não precisam ser exibidos visualmente para estarem expostos: basta que o cliente os leia do banco. Além disso, a remoção por desconexão é registrada somente em `players/{playerId}`; o nó histórico `members/{playerId}` permanece.

**Impacto:** divulgação desnecessária de atributos do dispositivo, criação de um perfil mais identificável quando combinados, retenção sem prazo explícito e divergência entre o que a interface sugere e o que o banco contém.

**Ações:**

- Melhor opção: não coletar metadados individuais se não houver necessidade operacional clara.
- Se métricas forem indispensáveis, reduza para dados agregados/anônimos e colete apenas os campos necessários, com finalidade, consentimento/aviso claro e prazo de retenção.
- Separe presença pública (`playerName`, cor, horário aproximado) de telemetria privada. Não coloque dados privados no mesmo nó que todos os jogadores podem ler.
- Remova o listener amplo de `members` ou faça com que leia somente um registro público mínimo.
- Defina expiração e exclusão das informações antigas; desconectar um jogador não deve deixar um histórico sem política de retenção.
- Reescreva o aviso de privacidade após definir exatamente o que é coletado, quem acessa, onde é salvo e por quanto tempo.

### P1 — A solução completa é publicada no Firebase

**Local:** `js/multiplayer-service.js:265-283`; validação de metadados em `287-307`.

`createRoomMeta()` serializa `solutionGrid` ao lado de `fixedInitialGrid` e dos demais metadados em `rooms/{roomId}/meta`. Qualquer cliente autorizado a ler esse caminho recebe a resposta inteira antes de terminar.

**Impacto:** um participante pode decodificar a solução antes de jogar, obter todas as respostas e fabricar um resultado. Isso destrói qualquer alegação de competição justa, pontuação confiável ou validação de conclusão baseada no cliente.

**Ações:**

- Não publique a solução junto aos metadados públicos da sala.
- Para modo competitivo, guarde a solução num local acessível apenas pelo servidor e execute no servidor a validação de movimentos, dicas e conclusão.
- Para modo single-player/offline, aceite que a solução entregue ao navegador pode ser inspecionada. Não trate um segredo que já foi enviado ao cliente como segredo.
- Revise também o código de compartilhamento: `js/sharing.js:10-25` inclui `sol` no objeto codificado. Base64 é codificação, não criptografia. O formato pode continuar sendo útil para compartilhamento offline, desde que isso não seja usado como mecanismo anti-cheat.

### P1 — O multiplayer confia no cliente para identidade, movimentos e pontuação

**Local:** `js/app-state.js:62-90`; `js/multiplayer-service.js:557-623`, `425-478`; `js/multiplayer-voting.js:3-139`, `324-385`.

O `playerId` é gerado localmente com `Math.random()`. O cliente informa `userId`, nome, cor, ação, coordenadas, valor e timestamp no log de movimentos. Também escreve contribuições, estado do tabuleiro, status de conclusão, votos e metadados de sala diretamente no Firebase. Não existe autenticação de usuário no SDK inicializado em `firebase-client.js`.

As verificações da interface (por exemplo, impedir digitar em uma pista fixa ou impedir um voto duplicado localmente) ajudam na experiência normal, mas são contornáveis por um cliente modificado. `Date.now()` fornecido pelo cliente não é prova confiável de quando uma jogada ocorreu.

**Impacto:** personificação de jogadores, votos falsos, contribuição atribuída à pessoa errada, estado concluído artificialmente, alteração de regras da sala, movimentação inválida e manipulação do tempo de conclusão.

**Ações:**

1. Use Firebase Authentication — autenticação anônima é possível se não quiser exigir cadastro — e baseie a identidade em `auth.uid`, nunca num identificador gerado pelo próprio código.
2. Defina associação e permissões de sala no servidor; valide que o autor pertence à sala e pode executar a ação.
3. Se o modo “versus” precisa resistir a trapaça, mova as operações críticas para Cloud Functions ou um backend equivalente com Firebase Admin SDK: receber intenção de jogada, validar ação/valor/pistas/estado, aplicar transação e registrar resultado de servidor.
4. Registre timestamps no servidor e trate o tempo do cliente apenas como dado de interface.
5. Use App Check como proteção complementar contra abuso de clientes não atestados; não o trate como substituto de Authentication, regras ou validação do jogo.

**Limite importante:** Security Rules conseguem impor autorização e restrições de esquema, mas não transformam um cliente hostil em árbitro confiável. Para anti-cheat real em multiplayer competitivo, a transição do estado precisa ser validada por uma autoridade de servidor.

### P1 — Validação do puzzle não garante uma solução válida, completa e compatível com as pistas

**Local:** `js/sudoku-engine.js:3-33`; importação em `js/sharing.js:28-63`; metadados em `js/multiplayer-service.js:287-307`.

`isValidMatrix()` verifica apenas dimensões e se cada valor é vazio ou pertence à lista de símbolos. `validateGameState()` não garante que:

- os símbolos sejam distintos;
- as pistas iniciais não tenham conflitos em linha, coluna ou bloco;
- a solução esteja completa;
- a solução satisfaça as regras do Sudoku;
- a solução concorde com todas as pistas iniciais;
- a grade tenha solução única;
- as dimensões dos blocos sejam inteiras e dividam corretamente `N`.

Um payload pode, portanto, passar pela validação estrutural mesmo contendo uma solução parcial ou inválida. No compartilhamento, `validMeta.sol` é aceito sem uma validação semântica adicional.

**Impacto:** puzzles impossíveis, várias soluções, dicas incorretas em relação à intenção do autor, erros destacados indevidamente e dados remotos/localmente salvos que corrompem o estado.

**Ações:** centralize um validador semântico independente de UI que valide a estrutura com limites rígidos, símbolos únicos, dimensões divisíveis, pistas sem conflito e solução completa válida. Quando a regra do produto exigir um Sudoku de solução única, conte soluções até duas (`0`, `1`, `2+`) e diferencie “sem solução”, “única” e “múltiplas”. A validação de qualquer payload deve terminar antes de alterar `state`.

### P1 — A verificação de vitória não confirma os invariantes completos do jogo

**Local:** `js/gameplay.js:14-46`.

`checkFullBoardSolution()` declara vitória se cada linha, coluna e bloco tiver `N` valores distintos. Não verifica explicitamente se todos os valores pertencem a `state.symbols`, se as pistas originais permanecem intactas ou se a grade bate com a solução canônica. Em condições normais de UI, algumas dessas condições são implicitamente respeitadas; elas não podem ser presumidas após importação, estado remoto ou adulteração.

**Impacto:** vitória falsa se o estado já estiver adulterado, sobretudo no multiplayer e em grades carregadas de payloads não confiáveis. Mesmo que uma regra de Sudoku válida e uma solução única tornem as verificações equivalentes em condições ideais, o código precisa impor essas condições, não presumir que elas sempre valerão.

**Ações:** validar todas as células contra os símbolos permitidos, preservar pistas fixas, validar linhas/colunas/blocos e comparar com a solução validada. No modo competitivo, executar a validação final no servidor; `completed` enviado pelo cliente nunca deve ser autoridade para resultado.

### P1 — Dados remotos malformados podem quebrar callbacks e interface

**Local:** `js/multiplayer-service.js:348-423`, `605-667`; `js/board-view.js:167-185`.

`applyRoomBoardState()` normaliza alguns valores com `String()` e verifica parte das dimensões, mas não valida completamente todos os elementos do tabuleiro contra `symbols`, as pistas, comprimento dos valores e o formato de notas/flags. `processIncomingMove()` aceita dados remotos sem uma validação de esquema completa: `userName` pode não ser string e `userColor` pode ser um valor arbitrário. Em `board-view.js`, `peer.name.charAt(0)` pressupõe uma string; `onRoomPlayersChanged()` também acessa propriedades do jogador sem validar que seja um objeto simples.

**Impacto:** exceções em atualizações em tempo real, renderização incompleta, valores inválidos no tabuleiro ou falha persistente da sala após uma gravação maliciosa ou acidental.

**Ações:** trate todo dado vindo do RTDB como entrada não confiável. Verifique `typeof`, limites, arrays/dimensões e enums antes de atualizar o estado; descarte registros inválidos sem interromper a renderização. Normalize nomes para strings limitadas e cores para uma allowlist/regex de cor. A validação deve ocorrer antes de modificar qualquer parte de `state`.

### P1 — Criação de sala pode substituir outra sala e deixar estado parcial

**Local:** `js/multiplayer-service.js:797-868`.

O ID gerado usa dois trechos de `Math.random()`, e uma sala com nome personalizado é convertida em chave por substituição de caracteres. Não há uma reserva atômica do identificador nem verificação segura de que a sala não existe antes de gravar. A inicialização escreve meta, tabuleiro, movimentos, contribuições, membros e configurações em chamadas separadas dentro de `Promise.all`. Hospedar com um ID existente pode substituir os dados dessa sala; falhas intermediárias podem deixar a criação incompleta.

**Impacto:** tomada acidental ou deliberada de sala, reset de partidas de terceiros, conflito de instância e sala parcialmente inicializada.

**Ações:** gerar IDs com `crypto.getRandomValues()` ou por uma função de servidor, impedir reutilização de IDs, validar o formato/limite tanto na criação como na entrada e fazer a criação atômica com operação condicional no servidor. Não aceite um ID escolhido pelo cliente como prova de que ele é dono da sala.

### P1 — Log de movimentos sem limite permite crescimento, custo e degradação

**Local:** `js/board-view.js:193-199`; `js/multiplayer-service.js:557-603`, `670-749`.

Cada foco de célula publica um registro `FOCUS`. Os registros são anexados em `moves`; a cada mudança, cada cliente recebe o objeto inteiro, ordena todas as entradas por timestamp, conta eventos NASA e percorre movimentos ainda não processados. Não identifiquei uma política de retenção/limpeza periódica; a limpeza ocorre em algumas transições de partida, não por tamanho ou idade.

**Impacto:** custo e tráfego crescentes, processamento O(M log M) por atualização quando existem M movimentos, uso de memória progressivo e possibilidade de spam por cliente que escreve no banco.

**Ações:** não use log append-only para cursores. Grave a posição/foco atual numa presença mutável por jogador e use eventos limitados para ações que realmente precisam de histórico. Defina limite de taxa, tamanho máximo, retenção/TTL e estratégia de paginação/consumo incremental. Acrescente monitoramento de tráfego e limites de custo.

### P2 — Escritas de tabuleiro inteiro podem sobrescrever mudanças concorrentes

**Local:** `js/multiplayer-service.js:425-478`, `557-603`; `js/input-controller.js:100-124`; `js/gameplay.js:35-39`, `90-124`.

O fluxo normal de célula publica atualização pontual, o que ajuda a reduzir sobrescritas. Porém, `publishRoomBoardState()` escreve um snapshot completo do tabuleiro. Essa operação aparece em eventos como uso da NASA/conclusão, enquanto outros clientes podem publicar alterações pontuais quase simultaneamente. Vários nós críticos também são atualizados em `Promise.all` separados, sem uma versão/commit atômico que faça o conjunto inteiro aparecer como uma transição indivisível.

**Impacto:** “última gravação vence”, perda de preenchimentos concorrentes e divergência temporária entre meta, tabuleiro, movimentos e contribuições.

**Ações:** adote versões de estado e transações, com validação de `instanceNumber`/versão e regras determinísticas de conflito. Prefira um único comando de servidor para aplicar a jogada e atualizar board/contribuição/log de forma coerente. Nunca publique um snapshot local potencialmente desatualizado para substituir alterações feitas desde que ele foi lido.

### P2 — Votações dependem de um proponente online e possuem condições de corrida

**Local:** `js/multiplayer-voting.js:3-139`, `142-221`, `324-385`.

A proposta é escrita diretamente pelo cliente. As respostas são registros manipuláveis se a autorização permitir, e a conclusão/execução é coordenada por clientes: a geração da nova grade é executada pelo proponente; a ação NASA também é executada no cliente do proponente. Se ele desconectar depois da aprovação, a ação pode nunca ser concluída. O cálculo de maioria roda em vários clientes, pode considerar listas de participantes diferentes por questões de sincronização e atualiza o status com gravações não atômicas. `requestFeatureVote()` verifica a votação ativa num estado local e usa `set()` diretamente; dois pedidos quase simultâneos podem sobrescrever um ao outro.

**Impacto:** propostas travadas, votos descartados ou adulterados, ações aprovadas que não se executam e resultados inconsistentes entre jogadores.

**Ações:** fazer uma função de servidor ser autoridade para abrir/resolver votação, definir elegibilidade num snapshot estável, rejeitar votos duplicados/fora de prazo e executar ações aprovadas independentemente de quem propôs. Operações de status precisam ser transacionais/idempotentes. O cliente deve apenas solicitar a ação e observar o resultado.

### P2 — Fluxos locais de criação e importação podem alterar uma partida multiplayer ativa

**Local:** `js/app-events.js:44-52`, `63-83`, `244-247`; `js/sharing.js:28-63`; `js/ocr-import.js:3-49`.

O botão principal de novo jogo solicita consenso durante multiplayer, mas a criação manual, a importação por código compartilhado e a importação OCR alteram diretamente o estado local sem exigir desconexão ou bloquear a operação. O jogador pode continuar com `multiplayer.active === true` e depois publicar ações desse tabuleiro local na sala antiga.

**Impacto:** o cliente fica com puzzle/solução/grade divergentes do estado compartilhado, quebra a coerência da sessão e pode provocar ações inválidas ou sobrescritas.

**Ações:** centralize as transições de modo. Enquanto estiver numa sala, bloquear importação OCR, importação de código, criação manual e alterações de configuração; alternativamente, exigir desconexão explícita e só então realizar a operação. Não basta desativar visualmente os botões: valide o estado também nos handlers.

### P2 — Puzzles manuais e OCR aceitam múltiplas soluções

**Local:** `js/app-events.js:71-83`; `js/ocr-import.js:25-47`; `js/sudoku-engine.js:162-204`.

`solvePartialGrid()` retorna uma solução encontrada, não prova que ela é a única. A criação manual e o OCR aceitam essa primeira solução. Se as pistas permitirem mais de uma resposta, a NASA e o destaque de erros escolhem arbitrariamente uma delas, penalizando respostas que também são válidas para as pistas fornecidas.

**Impacto:** regras percebidas como quebradas, dicas incoerentes, destaque de erros injusto e níveis de dificuldade imprevisíveis.

**Ações:** para puzzles que prometem solução única, contar soluções até duas antes de iniciar a partida. Para OCR, mostrar as pistas reconhecidas e pedir que o jogador as confirme/edite; não converter silenciosamente uma grade ambígua numa partida normal.

### P1 — Seeds das dificuldades “Doido”/“Uai Sô” podem deixar de gerar a partida ou violar unicidade

**Local:** `js/sudoku-engine.js:162-204`, `206-239`.

A geração especial para `doido` e `uaiso` confia em todos os strings de `SEEDS_17_CLUES`/`SEEDS_UAISO_BASE` sem validar previamente que cada seed pode ser resolvido dentro do limite do solver, que é único e que tem a quantidade de pistas esperada. Em teste determinístico dos seeds:

- `SEEDS_17_CLUES[3]` faz `solvePartialGrid()` retornar `null` dentro de seu limite de 60.000 passos; `buildIsomorphic9x9FromSeed()` tenta acessar `rawSolution[sr][sc]` e lança `TypeError: Cannot read properties of null`. Como `doido` escolhe esse conjunto aleatoriamente e `uaiso` também inclui esses seeds, há caminhos aleatórios de geração que falham sem tratamento.
- `SEEDS_17_CLUES[0]` permite que `countSolutionsMRV(..., limit=2)` encontre pelo menos duas soluções, então o código especial não garante a unicidade que o produto promete.
- `SEEDS_17_CLUES[2]` contém 21 pistas, mas o código espera 17 ou 18: `buildIsomorphic9x9FromSeed()` só adiciona pistas e nunca remove as excedentes.

O limite de passos de `solvePartialGrid()` também mistura “sem solução” e “não consegui achar dentro do orçamento”, ambos retornando `null`; o chamador não sabe qual ocorreu.

**Impacto:** exceção não tratada ao criar uma partida em dificuldade alta, partidas potencialmente ambíguas e dificuldade divergente da indicada. É uma falha funcional reproduzível, não apenas um risco teórico.

**Ações:** descarte/corrija os seeds problemáticos; valide todos os seeds offline num script de build com resultado reproduzível; exija exatamente uma solução antes de incorporá-los; não dereferencie solução nula; se o solver esgotar o orçamento, retorne um estado distinto de “sem solução” e trate isso sem quebrar a interface. O caminho especial deve ter testes determinísticos para cada seed e para ambos os níveis de dificuldade.

### P2 — Dimensões primas produzem “blocos” de 1×N

**Local:** `js/sudoku-engine.js:46-53`; uso em `index.html` e criação de sala.

`computeBlockDimensions()` escolhe o divisor mais próximo da raiz. Quando `N` é primo, resulta em `blockR=1`, `blockC=N`. O bloco coincide com a linha, então a regra de blocos não acrescenta restrições além de linha/coluna. O usuário ainda vê a experiência como Sudoku com sub-blocos.

**Impacto:** para N=5, 7, 11, 13, 17, 19 ou 23, o jogo se comporta como um quadrado latino, não como um Sudoku com regiões internas usuais.

**Ações:** escolha e documente explicitamente uma variante para tamanhos primos, ou impeça dimensões que não possam formar regiões de Sudoku significativas. Valide que `blockR` e `blockC` são inteiros positivos e divisores de `N`.

### P2 — Código compartilhado não é validado integralmente e altera estado antes da validação final

**Local:** `js/sharing.js:28-63`.

O loader valida inicialmente apenas parte da estrutura. Notas, `revealedErrors`, contadores, tempo, `mode`/`difficulty` e relação entre tabuleiro, pistas e solução são aceitos com checagens incompletas. Por exemplo, `rawData.n.map(row => row.map(...))` pode falhar com linhas malformadas. Ao mesmo tempo, várias propriedades globais são modificadas antes da validação terminar; o `catch` retorna `false`, mas não restaura o estado anterior. Não há limite explícito para o tamanho do código recebido antes de decodificar/parsear.

**Impacto:** carregamento parcialmente aplicado, estado corrompido, interface em erro ou consumo excessivo de memória com payload enorme.

**Ações:** limitar o tamanho do payload; analisar para um objeto temporário; validar schema estrito, matrizes, notas, limites de contador/tempo e solução; só então substituir `state` de forma atômica. Em falha, manter o jogo anterior intacto.

### P2 — Histórico local considera um registro válido após validar só parte dele

**Local:** `js/game-storage.js:3-43`, `46-108`.

`getAllSavedGames()` filtra registros com `validateGameState()`, mas retorna o objeto original em vez do registro normalizado. Campos como `board`, `notes`, `timerSeconds`, `updatedAt`, `gameName`, `N` e a relação das matrizes não são inteiramente validados. `renderHistoryModalList()` pressupõe que `board` e `initial` tenham a forma correta e interpola `item.N` numa declaração CSS e em loops.

**Impacto:** JSON local antigo ou corrompido pode travar a renderização do histórico ou fazer `loadSavedGameRecord()` carregar matrizes inconsistentes. Isso é sobretudo um problema de robustez local; não identifiquei um caminho direto de escrita remota no `localStorage`.

**Ações:** criar um schema de histórico completo e sempre usar o objeto normalizado produzido pelo validador. Revalidar imediatamente antes de carregar. Limitar N, strings, notas e contadores. Renderizar a prévia com elementos DOM em vez de construir HTML a partir de campos do registro.

### P2 — A API `localStorage` pode impedir a inicialização em ambientes restritivos

**Local:** `js/app-events.js:117-119`, `221`, `231`, `308-318`; `js/game-storage.js:107`.

Alguns acessos a `localStorage.getItem()`/`setItem()` não estão protegidos por `try/catch`, embora outros pontos do projeto já lidem com erro. Se armazenamento estiver bloqueado, indisponível ou quota excedida, o clique ou a inicialização pode lançar exceção.

**Ações:** encapsular armazenamento num adaptador que trate `SecurityError`/quota, permita operação sem persistência e valide JSON. Não silenciar toda exceção sem ao menos registrar o motivo em diagnóstico de desenvolvimento.

### P2 — OCR sem limites suficientes de arquivo e sem limpeza garantida

**Local:** `js/app-events.js:244-247`; `js/ocr-import.js:3-49`.

O `input` aceita `image/*`, o que é só uma indicação para o seletor de arquivos. Não existe limite explícito de bytes/dimensões antes da decodificação, o `objectURL` criado não é revogado e o worker do Tesseract só é encerrado no caminho de sucesso. Arquivos grandes ou malformados podem consumir muita memória ou deixar worker/recursos ativos após falha.

**Ações:** validar tipo MIME real, tamanho do arquivo e dimensões; lidar com `img.onerror`; revogar URLs em `finally`/após processamento; encerrar workers em bloco `finally`; permitir cancelar OCR e limitar o tempo de processamento. O arquivo é processado localmente no código observado, mas a dependência OCR vem de CDN e deve estar incluída na revisão de terceiros.

### P2 — Solução e histórico ficam em armazenamento local sem política de privacidade/expiração

**Local:** `js/game-storage.js:4-23`.

Até 35 jogos são mantidos em `localStorage`, incluindo solução, pistas, estado completo, anotações, tempos, nome e métricas de NASA. Em dispositivo compartilhado, qualquer pessoa que use o mesmo perfil do navegador/WebView pode inspecionar esses dados. Não estão criptografados — o que é normal para `localStorage`, mas não deve ser tratado como cofre seguro.

**Ações:** não guardar dados que não precisam persistir; permitir apagar todo o histórico; explicar que os dados são locais; usar armazenamento do perfil do app no empacotamento nativo e não prometer proteção contra outro usuário com acesso ao mesmo perfil/dispositivo.

### P2 — Timer e resultados não são confiáveis para ranking

**Local:** `js/gameplay.js:53-64` e publicação do estado em `js/multiplayer-service.js:425-438`.

O tempo é acumulado por `setInterval`, sujeito à suspensão/throttling de abas em segundo plano. O jogador também pode pausar, ajustar o relógio ou alterar o estado local; no multiplayer, `elapsedSeconds`/`isCompleted` são enviados por cliente.

**Impacto:** tempo de jogo pode divergir do tempo real e não pode servir de prova de mérito em ranking competitivo.

**Ações:** para experiência casual, calcular tempo decorrido com uma referência monotônica e intervalos de pausa. Para ranking, cronometrar e validar no servidor, com política explícita para pausa, desconexões e retomadas.

### P2 — Dependências front-end externas aumentam risco de supply chain e variabilidade

**Local:** `index.html:8-22`; SDK em `js/firebase-client.js:1-4`.

Tailwind é carregado pelo Play CDN, que a própria documentação descreve como voltado a desenvolvimento, não produção. Tesseract usa `@5` sem patch fixo; scripts e folhas CSS externas não têm SRI no HTML. Uma mudança externa ou indisponibilidade pode alterar a execução ou quebrar funcionalidades sem uma nova publicação do seu código.

**Ações:** compilar Tailwind em CSS estático; empacotar/declarar versões exatas de dependências e lockfile; atualizar de forma controlada; configurar CSP e cabeçalhos de segurança na hospedagem; reduzir dependências externas e verificar licenças. SRI pode ser usado quando compatível, mas um bundle controlado é preferível para scripts complexos com dependências adicionais.

### P2 — Aviso de privacidade contradiz o ciclo de vida dos dados

**Local:** `index.html:853-855`; caminhos persistentes `rooms/{roomId}/meta`, `boardState`, `moves`, `contributions` e `members`.

A interface afirma que “as partidas em si não são guardadas”, mas o banco recebe a grade, metadados, estado completo, solução, histórico de movimentos e contribuições. Não encontrei, no código analisado, política geral de expiração/exclusão da sala. O aviso também não informa que outros clientes podem ler `clientMetadata`.

**Ações:** corrigir o modelo de retenção primeiro e só depois escrever o aviso. Definir expiração de salas inativas, apagar dados derivados ao vencer o prazo e documentar o que fica no servidor e localmente. Disponibilizar mecanismo de exclusão quando aplicável.

### P3 — Servidor local distribui arquivos desnecessários do projeto

**Local:** `servidor-local.ps1:97-136`.

O servidor escuta em `IPAddress::Loopback`, o que limita conexões ao próprio computador, aceita apenas GET/HEAD e contém uma checagem de caminho que mitiga traversal simples. Isso é positivo. No entanto, ele serve qualquer arquivo dentro da pasta raiz, não só os artefatos que o app precisa, podendo expor README, scripts, arquivos em `misc` e a versão antiga em `Trivia` a outro processo/site local que consiga acessar a porta.

**Ações:** publicar a partir de uma pasta `dist/` contendo apenas arquivos necessários, manter o bind em loopback para uso local, adicionar timeouts/limites de resposta e cabeçalhos de segurança. Para hospedagem pública, usar servidor estático gerenciado com HTTPS e cabeçalhos adequados, não o script PowerShell.

### P3 — Artefatos legados e configuração duplicada aumentam risco de manutenção

**Local:** `Trivia/[DEPRECATED] Sudoku Aneróthico PRÓ 5.2 monolítico.html`, `misc/firebaseConfig.txt`, `.gitignore`.

O ZIP inclui uma versão monolítica depreciada e uma configuração Firebase alternativa que parece ser de desenvolvimento/versão antiga. Mesmo sendo a configuração web pública, arquivos duplicados criam risco de editar a versão errada, manter SDKs diferentes ou publicar acidentalmente conteúdo desnecessário.

**Ações:** separar projeto-fonte, testes, documentação e artefatos de distribuição; remover arquivos depreciados da pasta publicada; manter uma única configuração por ambiente e um processo explícito de build. Amplie `.gitignore` para artefatos gerados e arquivos locais sensíveis — especialmente quaisquer credenciais de servidor que venham a ser introduzidas no futuro.

### P3 — Falta de cabeçalhos de segurança no servidor local e necessidade de endurecimento no hosting

**Local:** `servidor-local.ps1:88-94`; `index.html` sem política CSP observada.

O servidor local envia `X-Content-Type-Options: nosniff` e `Cache-Control: no-cache`, mas não define CSP, `Referrer-Policy`, `Permissions-Policy` ou política de framing. Esses cabeçalhos são mais relevantes no hosting público, que deve ser configurado separadamente; uma tag meta CSP é menos flexível que um cabeçalho HTTP e pode exigir ajustes por haver scripts inline/terceiros.

**Ações:** estabelecer CSP com allowlist explícita após compilar/bundlar os scripts; bloquear framing não desejado (`frame-ancestors 'none'`), limitar referrer e APIs do navegador, servir sempre via HTTPS. Testar CSP em relatório antes de impor bloqueio para descobrir dependências legadas.

### P3 — UX pode ficar inconsistente em falhas de sincronização ou desconexão

**Local:** `js/multiplayer-service.js:480-501`, `751-795`, `797-868`; `js/gameplay.js:90-124`.

Algumas falhas são registradas apenas no console ou suprimidas; a presença e a inicialização da sala ocorrem em operações assíncronas distintas. Uma falha parcial pode deixar a interface com status otimista ou o tabuleiro local alterado mesmo quando a sincronização não ocorreu. O registro de membro fica, intencionalmente ou não, após desconectar.

**Ações:** representar estados `connecting`, `connected`, `syncing`, `offline`, `failed`; só confirmar operações ao receber resultado; fornecer recuperação/reatentativa idempotente e mostrar quando o jogo está dessincronizado. Incluir limpeza de presença e política de retenção separada.

---

## 5. Pontos positivos encontrados

- Os arquivos JavaScript não apresentaram erros de sintaxe em `node --check`.
- O servidor local escuta em loopback (`127.0.0.1`), não em todas as interfaces de rede.
- O servidor local aceita GET/HEAD apenas, define `X-Content-Type-Options: nosniff` e faz checagem de prefixo do caminho antes de servir arquivos.
- Toasts, nomes de jogadores e vários textos remotos são inseridos via `textContent`, o que evita injeção HTML nesses locais. Não encontrei um caminho óbvio de XSS persistente via nome de jogador nos principais componentes revisados.
- Há tentativa de atualizar células pontualmente no fluxo normal e uso de transação na atribuição de cor, embora isso não resolva a autoridade de usuário nem todas as corridas.
- O código de exportação revoga o `objectURL` gerado em seu fluxo de sucesso; a importação OCR ainda precisa de limpeza equivalente, inclusive em erro.

Esses pontos positivos não compensam os bloqueadores de privacidade, banco aberto e confiança multiplayer.

## 6. Ordem recomendada para resolver

### Fase A — Conter o risco enquanto desenvolve

1. Use somente o Emulator Suite ou um projeto Firebase de desenvolvimento sem dados reais enquanto as regras estiverem abertas.
2. Não compartilhe nem publique a URL apontando para o projeto aberto.
3. Remova `clientMetadata` do nó comum de membros e retire `solutionGrid` do caminho público da sala como correções imediatas de redução de exposição. Isso reduz dados expostos, mas não torna o multiplayer anti-cheat.
4. Pare de criar logs `FOCUS` no histórico append-only; use um estado de cursor mutável por jogador.

### Fase B — Definir a fronteira de confiança multiplayer

1. Adotar Firebase Authentication (anônima, se adequada) e identidade por `auth.uid`.
2. Definir um modelo de permissão explícito: criar sala, entrar, votar, jogar, pedir dica, reiniciar e encerrar.
3. Mover mutações competitivas para Cloud Functions/backend; o cliente envia intenções, não o estado autoritativo final.
4. Guardar a solução fora dos caminhos que jogadores podem ler. Validar jogadas, pistas, temporização, contribuições e vitória no servidor.
5. Tornar criação/entrada/novo jogo/votação transacionais ou idempotentes e impedir sobrescrita de salas existentes.
6. Definir esquema e limites de tamanho/rate-limit no servidor e nas Security Rules. Ativar App Check como defesa complementar.

### Fase C — Corrigir domínio e dados

1. Implementar um validador de puzzle único e completo, que opere sem modificar o estado atual.
2. Validar puzzle inicial, solução completa, pistas preservadas, símbolos únicos, regiões válidas e unicidade quando requerida.
3. Tornar carregamento de código, OCR e histórico transacional: parsear, validar tudo e somente então aplicar.
4. Bloquear operações offline que conflitem com uma sala ativa.
5. Corrigir seeds e regras para dimensões primas.
6. Definir retenção, exclusão e aviso de privacidade de acordo com o comportamento real.

### Fase D — Preparar o pacote de distribuição

1. Criar `dist/` com uma allowlist de arquivos publicados; remover `Trivia`, `misc` e scripts de desenvolvimento do pacote.
2. Compilar Tailwind, fixar versões de dependências, manter lockfile e atualizar deliberadamente.
3. Configurar HTTPS, CSP, `frame-ancestors`, `Referrer-Policy`, `Permissions-Policy`, quotas/alertas de Firebase e monitoramento.
4. Revisar acessibilidade e estados de erro/offline em browser desktop, mobile browser, Windows e Android/WebView.
5. Só então criar pipeline de build/deploy.

### Fase E — Testes automatizados antes de liberar

Embora os testes possam ser escritos depois de estabilizar a primeira arquitetura, **não adie os testes de regras e de concorrência até o final**: eles são parte do mecanismo que prova a correção das medidas de segurança.

Mínimo necessário:

- **Unitários:** validação de matriz, símbolos, blocos, givens, solução única, gerador, seeds, serialização, parsing de código e normalização de metadados.
- **Property-based/fuzz:** grades com dimensões inválidas, valores enormes, tipos incorretos, arrays truncados, payloads grandes, timestamps futuros/passados, nomes/cores não conformes.
- **Security Rules via Emulator Suite:** anônimo, membro, não membro, host, tentativa de ler solução, tentativa de alterar pistas/owner/voto/contribuição, acesso a sala inexistente e exclusão não autorizada.
- **Integração multiplayer:** duas ou mais instâncias concorrendo pela mesma célula, reinício com evento em voo, desconexão do proponente, voto simultâneo, sala repetida e rede intermitente.
- **Anti-cheat:** escrever `isCompleted`, solução, timestamp ou atribuição diretamente; a API deve rejeitar a tentativa e manter o estado canônico.
- **Desempenho:** spam de foco/movimento, logs longos, sala lotada e payloads malformados.
- **UI/storage:** localStorage desabilitado, registro corrompido, OCR inválido/grande, código compartilhado malformado e tentativa de importar durante multiplayer.

## 7. Critérios de saída antes da publicação

Não considere a estrutura pronta até que todos os itens abaixo sejam verificáveis:

- [ ] Regras do RTDB negam por padrão e testes automatizados provam que usuários sem permissão não leem/escrevem.
- [ ] Authentication define identidade confiável e a autorização verifica membership/role.
- [ ] Solução e dados privados não são lidos por outros jogadores.
- [ ] Alterações competitivas são validadas por servidor, não pelo cliente.
- [ ] Escritas concorrentes mantêm um único estado canônico e não perdem jogadas silenciosamente.
- [ ] Toda entrada remota/importada passa por esquema estrito antes de mudar estado.
- [ ] Soluções, pistas, unicidade e conclusão são validadas de forma consistente.
- [ ] Há limite e retenção para salas, movimentos, telemetria e dados históricos.
- [ ] Aviso de privacidade corresponde exatamente à coleta, compartilhamento e retenção reais.
- [ ] Dependências e headers de produção estão definidos; o pacote não serve arquivos de desenvolvimento.
- [ ] Testes de regras, lógica de Sudoku, concorrência, falhas de rede e fuzzing passam no CI.

## 8. Referências oficiais relevantes

- Firebase Realtime Database Security Rules: https://firebase.google.com/docs/database/security/?hl=pt-br
- Firebase Security Rules — modo bloqueado e modo de teste: https://firebase.google.com/docs/rules/basics?hl=pt-br
- Firebase Realtime Database — condições e validação: https://firebase.google.com/docs/database/security/rules-conditions?hl=pt-br
- Firebase App Check: https://firebase.google.com/docs/app-check?hl=pt-br
- Tailwind CSS Play CDN (desenvolvimento, não produção): https://tailwindcss.com/docs/installation/play-cdn

---

**Conclusão:** o jogo tem uma base funcional e alguns cuidados corretos de renderização, mas os atuais caminhos de multiplayer e privacidade não devem ser considerados “blindados”. A maior decisão arquitetural é se o modo competitivo precisa realmente resistir a clientes hostis. Se sim, o servidor precisa controlar o estado e a solução. Depois disso, endurecer regras, corrigir validação e concorrência, reduzir coleta/retenção e testar no emulador será um caminho muito mais sólido do que tentar compensar tudo apenas no JavaScript.
