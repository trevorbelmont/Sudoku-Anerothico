/**
 * helpers/engine-loader.js
 *
 * Carrega e expõe todas as funções puras do sudoku-engine.js e de módulos
 * auxiliares sem exigir DOM, Firebase ou qualquer dependência externa.
 *
 * Estratégia:
 *  - Lê os fontes como texto.
 *  - Remove as linhas de import/export ES6 (usadas apenas pelo firebase-client).
 *  - Avalia em um Function() isolado, injetando stubs mínimos para os
 *    identificadores globais que o motor referencia (state, DIFFICULTY_REMOVAL_RATIOS,
 *    document, etc.).
 *  - Retorna um objeto com todas as funções expostas.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

const JS = p => fs.readFileSync(path.resolve(__dirname, '../../js', p), 'utf8');

// Remove linhas de import/export ES6 que quebrariam a avaliação com new Function()
function stripModuleDirectives(src) {
  return src
    .replace(/^\s*import\s+.*?['"];?\s*$/gm, '')
    .replace(/^\s*export\s+/gm, '');
}

// ─── Stubs mínimos ─────────────────────────────────────────────────────────

function makeDOMStub() {
  return {
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    documentElement: { setAttribute: () => {}, style: { setProperty: () => {} } },
    body: { classList: { contains: () => false } },
    createElement: (tag) => ({
      tagName: tag.toUpperCase(),
      className: '',
      style: {},
      dataset: {},
      classList: { add: () => {}, remove: () => {}, toggle: () => {} },
      appendChild: () => {},
      getAttribute: () => null,
      setAttribute: () => {},
    }),
  };
}

function makeStateStubb() {
  return {
    mode: 'standard',
    difficulty: 'medio',
    N: 9,
    blockR: 3,
    blockC: 3,
    symbols: ['1','2','3','4','5','6','7','8','9'],
    board: [],
    initial: [],
    solution: [],
    notes: [],
    nasaContributions: [],
    nasaCalls: 0,
    revealedErrors: [],
    focusedCell: { r: 0, c: 0 },
    highlightedSymbol: null,
    pencilMode: false,
    immediateErrorCheck: false,
    highlightSameNumbers: true,
    timerSeconds: 0,
    timerRunning: false,
    timerInterval: null,
    completed: false,
    historyTab: 'ongoing',
    typingBuffer: '',
    typingTimeout: null,
    isManualCreating: false,
    boardZoom: 1,
    boardFocusMode: false,
    boardZoomBeforeFocus: null,
    visualSettings: {},
    multiplayer: {
      active: false, roomId: null, playerName: 'Jogador',
      playerId: 'player_test123', listeners: [], peers: {},
      contributions: {}, members: {}, players: {}, roomMode: 'coop',
      realtimeMetrics: false, color: '',
    },
    minVal: 1, maxVal: 9, includeZero: false,
    gameName: '', gameId: null,
  };
}

function loadEngineModule() {
  const src = stripModuleDirectives(JS('core/sudoku-engine.js'));

  // Stubs para funções de UI chamadas pelo engine
  const noopFns = [
    'updateDifficultyCluesUI', 'renderSudokuBoard', 'showToast',
    'updateCustomRangePreview', 'updateProgressUI', 'saveCurrentGameState',
    'syncModeTabsUI', 'updateHeaderSubtitle', 'renderVirtualNumpad',
    'updateAllCellVisuals',
  ].reduce((acc, name) => { acc[name] = () => {}; return acc; }, {});

  const DIFFICULTY_REMOVAL_RATIOS = {
    facil: 0.42, medio: 0.54, dificil: 0.63, uaiso: 0.716, doido: 0.79,
  };

  const state = makeStateStubb();
  const document = makeDOMStub();

  const exports = {};

  // Avalia o módulo; as funções ficam no escopo local da Function()
  // Precisamos expô-las explicitamente — usamos um objeto compartilhado
  const ctx = {
    state,
    document,
    DIFFICULTY_REMOVAL_RATIOS,
    ...noopFns,
    _exports: exports,
  };

  // Injeta as funções no objeto _exports ao final
  const wrapper = `
${src}

// Auto-export de todas as funções declaradas no engine
_exports.isValidMatrix           = isValidMatrix;
_exports.validateGameState       = validateGameState;
_exports.buildSymbolsFromRange   = buildSymbolsFromRange;
_exports.computeBlockDimensions  = computeBlockDimensions;
_exports.shuffleArray             = shuffleArray;
_exports.generateCompleteValidGrid = generateCompleteValidGrid;
_exports.solvePartialGrid         = solvePartialGrid;
_exports.countSolutionsMRV        = countSolutionsMRV;
_exports.createUniqueSudokuPuzzle = createUniqueSudokuPuzzle;
_exports.buildIsomorphic9x9FromSeed = buildIsomorphic9x9FromSeed;
_exports.SEEDS_17_CLUES           = SEEDS_17_CLUES;
_exports.SEEDS_UAISO_BASE         = SEEDS_UAISO_BASE;
_exports.DIFFICULTY_REMOVAL_RATIOS = DIFFICULTY_REMOVAL_RATIOS;
  `;

  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);

  return exports;
}

function loadConfigModule() {
  const src = stripModuleDirectives(JS('core/config.js'));
  const exports = {};
  const wrapper = `${src}\n_exports.APP_CONFIG = APP_CONFIG;`;
  const ctx = { _exports: exports };
  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);
  return exports.APP_CONFIG;
}

function loadAppStateModule() {
  const APP_CONFIG = loadConfigModule();
  const src = stripModuleDirectives(JS('core/app-state.js'));

  // Stub de localStorage
  const storage = {};
  const localStorageMock = {
    getItem: k => storage[k] ?? null,
    setItem: (k, v) => { storage[k] = String(v); },
    removeItem: k => { delete storage[k]; },
    clear: () => { Object.keys(storage).forEach(k => delete storage[k]); },
  };

  const cryptoMock = {
    getRandomValues: (arr) => { for (let i = 0; i < arr.length; i++) arr[i] = Math.floor(Math.random() * 256); return arr; },
  };

  const Intl = { DateTimeFormat: () => ({ resolvedOptions: () => ({ timeZone: 'America/Sao_Paulo' }) }) };

  const exports = { _storage: storage };

  const wrapper = `
${src}

_exports.STORAGE_KEYS               = STORAGE_KEYS;
_exports.DIFFICULTY_LABELS          = DIFFICULTY_LABELS;
_exports.DIFFICULTY_REMOVAL_RATIOS  = DIFFICULTY_REMOVAL_RATIOS;
_exports.ROOM_PROTECTION_DAYS       = ROOM_PROTECTION_DAYS;
_exports.state                      = state;
_exports.getOrCreatePersistentPlayerId = getOrCreatePersistentPlayerId;
_exports.loadVisualSettings         = loadVisualSettings;
  `;

  const ctx = { localStorage: localStorageMock, crypto: cryptoMock, Intl, APP_CONFIG, _exports: exports };
  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);

  return exports;
}

function loadUiHelpersModule() {
  const src = stripModuleDirectives(JS('ui/ui-helpers.js'));
  const exports = {};
  const wrapper = `
${src}
_exports.formatTime = formatTime;
_exports.showToast  = showToast;
  `;
  // showToast precisa de DOM; injetamos stub
  const document = makeDOMStub();
  const container = {
    appendChild: () => {},
    querySelectorAll: () => [],
  };
  const domSpy = {
    ...document,
    getElementById: (id) => id === 'toast-container' ? container : null,
    createElement: (tag) => ({
      tagName: tag.toUpperCase(),
      className: '',
      style: {},
      appendChild: () => {},
      remove: () => {},
    }),
  };
  const ctx = { document: domSpy, setTimeout: (fn) => fn(), _exports: exports };
  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);
  return exports;
}

function loadMultiplayerServiceColorModule() {
  // Extrai apenas as funções puras de cor (sem Firebase, sem state)
  const APP_CONFIG = loadConfigModule();
  const src = stripModuleDirectives(JS('network/multiplayer-service.js'));

  const exports = {};
  const stateMock = {
    multiplayer: { color: '', playerId: 'test_player', playerName: 'Tester', players: {}, members: {}, peers: {} },
  };

  const wrapper = `
${src}
_exports.normalizePlayerColor          = normalizePlayerColor;
_exports.stablePlayerColorHash         = stablePlayerColorHash;
_exports.playerColorToOKLab            = playerColorToOKLab;
_exports.playerColorPerceptualDistance = playerColorPerceptualDistance;
_exports.chooseMostDistinctPlayerColor = chooseMostDistinctPlayerColor;
_exports.detectClientBrowser           = detectClientBrowser;
_exports.detectClientOperatingSystem   = detectClientOperatingSystem;
_exports.collectClientMetadata         = collectClientMetadata;
_exports.MULTIPLAYER_PLAYER_COLOR_PALETTE = MULTIPLAYER_PLAYER_COLOR_PALETTE;
  `;

  const navigator = {
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36',
    language: 'pt-BR', languages: ['pt-BR', 'en-US'], onLine: true, platform: 'Win32',
    connection: null, userAgentData: null,
  };

  // getFirebaseAPI e roomPath são usados fora das funções puras; o wrapper não os chama
  const noops = {
    getFirebaseAPI: () => null,
    roomPath: () => '',
    state: stateMock,
  };

  const ctx = { navigator, APP_CONFIG, _exports: exports, ...noops };
  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  try { new Function(...keys, wrapper)(...vals); } catch (e) {
    // Algumas funções assíncronas (async) que dependem de Firebase falharão silenciosamente;
    // apenas as puras exportadas acima são necessárias para os testes de cor.
  }
  return exports;
}

function loadSharingModule() {
  const src = stripModuleDirectives(JS('services/sharing.js'));
  const exports = {};

  const stateMock = makeStateStubb();

  // solvePartialGrid e outras funções do engine precisam estar disponíveis
  const engine = loadEngineModule();

  const wrapper = `
${src}
_exports.processLoadedCode   = processLoadedCode;
_exports.shareCurrentPuzzleURL      = shareCurrentPuzzleURL;
_exports.shareCurrentPuzzleStateURL = shareCurrentPuzzleStateURL;
  `;

  const ctx = {
    state: stateMock,
    _exports: exports,
    validateGameState: engine.validateGameState,
    isValidMatrix: engine.isValidMatrix,
    solvePartialGrid: engine.solvePartialGrid,
    ensureNasaContributionGrid: () => {},
    buildSymbolsFromRange: engine.buildSymbolsFromRange,
    // DOM/UI stubs
    showToast: () => {},
    syncModeTabsUI: () => {},
    syncDifficultyButtonsUI: () => {},
    updateHeaderSubtitle: () => {},
    renderVirtualNumpad: () => {},
    renderSudokuBoard: () => {},
    startTimer: () => {},
    pauseTimer: () => {},
    saveCurrentGameState: () => {},
    formatTime: (s) => String(s),
    setGameNameInput: () => {},
    updateProgressUI: () => {},
    updateNasaContributionSummary: () => {},
    navigator: { clipboard: { writeText: () => Promise.resolve() } },
    document: {
      getElementById: () => ({ textContent: '', classList: { remove: () => {}, add: () => {} } }),
    },
    btoa: (s) => Buffer.from(s).toString('base64'),
    atob: (s) => Buffer.from(s, 'base64').toString('utf8'),
    encodeURIComponent,
    decodeURIComponent,
  };

  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);
  return { exports, state: stateMock };
}

function loadMultiplayerVotingModule() {
  const APP_CONFIG = loadConfigModule();
  const src = stripModuleDirectives(JS('network/multiplayer-voting.js'));
  const exports = {};

  const state = makeStateStubb();

  // Réplica fiel de isNASAContributionEntry (definida em board-view.js)
  function isNASAContributionEntry(entry) {
    return !!entry && (entry.kind === 'NASA' || entry.action === 'NASA' || entry.playerId === 'NASA' || entry.playerName === 'NASA');
  }

  // Réplica fiel de getNasaContributionStats (definida em board-view.js),
  // usando apenas state.nasaContributions e state.nasaCalls.
  function ensureNasaContributionGrid() {
    if (!Array.isArray(state.nasaContributions) || state.nasaContributions.length !== state.N) {
      state.nasaContributions = Array.from({ length: state.N }, () => Array(state.N).fill(false));
    }
  }

  function isNasaContributionCell(row, column) {
    ensureNasaContributionGrid();
    if (state.multiplayer && state.multiplayer.active) {
      const contributions = state.multiplayer.contributions || {};
      const key = row + '_' + column;
      if (Object.prototype.hasOwnProperty.call(contributions, key)) return isNASAContributionEntry(contributions[key]);
    }
    return !!(state.nasaContributions[row] && state.nasaContributions[row][column]);
  }

  function getNasaContributionStats() {
    ensureNasaContributionGrid();
    let nasaOwnedCells = 0;
    let editableFilled = 0;
    for (let r = 0; r < state.N; r++) for (let c = 0; c < state.N; c++) {
      if (state.initial && state.initial[r] && state.initial[r][c] !== '') continue;
      if (state.board && state.board[r] && state.board[r][c] !== '') {
        editableFilled++;
        if (isNasaContributionCell(r, c)) nasaOwnedCells++;
      }
    }
    const currentNasaCellCount = nasaOwnedCells;
    const callCount = Math.max(0, Number.isFinite(Number(state.nasaCalls)) ? Number(state.nasaCalls) : 0) || currentNasaCellCount;
    const humanFilledCells = Math.max(0, editableFilled - currentNasaCellCount);
    const totalContributions = humanFilledCells + callCount;
    return { count: callCount, cells: currentNasaCellCount, total: totalContributions, percent: totalContributions ? Math.round(callCount / totalContributions * 100) : 0 };
  }

  const wrapper = `
${src}
_exports.computeContributionStats = computeContributionStats;
  `;

  const ctx = {
    state,
    isNASAContributionEntry,
    getNasaContributionStats,
    APP_CONFIG,
    _exports: exports,
  };

  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  try {
    // eslint-disable-next-line no-new-func
    new Function(...keys, wrapper)(...vals);
  } catch (_) {
    // Outras funções do módulo dependem de Firebase/DOM; só computeContributionStats importa aqui.
  }
  return { exports, state };
}

function loadGameStorageModule() {
  const APP_CONFIG = loadConfigModule();
  const src = stripModuleDirectives(JS('services/game-storage.js'));
  const exports = {};

  // localStorage mock compartilhado entre save e getAll
  const storage = {};
  const localStorageMock = {
    getItem: k => storage[k] ?? null,
    setItem: (k, v) => { storage[k] = String(v); },
    removeItem: k => { delete storage[k]; },
    clear: () => { Object.keys(storage).forEach(k => delete storage[k]); },
  };

  const engine = loadEngineModule();
  const appState = loadAppStateModule();

  const state = makeStateStubb();

  // Elemento de badge para updateSavedBadgeCount
  const badgeEl = { textContent: '' };
  const documentMock = {
    ...makeDOMStub(),
    getElementById: (id) => {
      if (id === 'saved-count-badge') return badgeEl;
      if (id === 'manual-create-bar') return { classList: { add: () => {}, remove: () => {} } };
      if (id === 'timer-display') return { textContent: '' };
      return null;
    },
  };

  // Garante que state.nasaContributions tem o tamanho correto de N
  const ensureNasaContributionGrid = () => {
    if (!Array.isArray(state.nasaContributions) || state.nasaContributions.length !== state.N) {
      state.nasaContributions = Array.from({ length: state.N }, () => Array(state.N).fill(false));
    }
  };

  const wrapper = `
${src}
_exports.getAllSavedGames       = getAllSavedGames;
_exports.saveCurrentGameState    = saveCurrentGameState;
_exports.updateSavedBadgeCount  = updateSavedBadgeCount;
  `;

  const ctx = {
    localStorage: localStorageMock,
    STORAGE_KEYS: appState.STORAGE_KEYS,
    APP_CONFIG,
    validateGameState: engine.validateGameState,
    state,
    ensureNasaContributionGrid,
    computeBlockDimensions: engine.computeBlockDimensions,
    buildSymbolsFromRange: engine.buildSymbolsFromRange,
    formatTime: (s) => String(s),
    document: documentMock,
    _exports: exports,
  };

  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  // eslint-disable-next-line no-new-func
  new Function(...keys, wrapper)(...vals);

  return { exports, state, storage, localStorageMock, badgeEl, STORAGE_KEYS: appState.STORAGE_KEYS };
}

function loadPanelSystemModule() {
  const APP_CONFIG = loadConfigModule();
  const src = stripModuleDirectives(JS('ui/panel-system.js'));
  const exports = {};

  const storage = {};
  const localStorageMock = {
    getItem: k => storage[k] ?? null,
    setItem: (k, v) => { storage[k] = String(v); },
  };

  const panelEl = {
    classList: { add: jest.fn(), remove: jest.fn(), contains: () => false },
    offsetWidth: 280,
    getBoundingClientRect: () => ({ width: 280 }),
  };

  const resizerEl = {
    classList: { add: jest.fn(), remove: jest.fn() },
    addEventListener: jest.fn(),
  };

  const collapseEl = {
    classList: { add: jest.fn(), remove: jest.fn() },
    addEventListener: jest.fn(),
    setAttribute: jest.fn(),
    querySelector: () => null,
    querySelectorAll: () => [],
  };

  const documentMock = {
    querySelector: (sel) => {
      if (sel === '.panel-left')    return panelEl;
      if (sel === '.panel-resizer') return resizerEl;
      if (sel === '.panel-collapse-btn') return collapseEl;
      return null;
    },
    querySelectorAll: () => [],
    getElementById: () => null,
    documentElement: { style: { setProperty: jest.fn() } },
    body: { classList: { contains: () => false } },
    addEventListener: jest.fn(),
  };

  const wrapper = `
${src}
// PanelSystem é uma IIFE; expõe funções via objeto interno
  `;

  // A IIFE se auto-executa mas depende de document.querySelector; passamos o mock
  const ctx = {
    document: documentMock,
    localStorage: localStorageMock,
    window: { addEventListener: jest.fn() },
    renderSudokuBoard: jest.fn(),
    state: makeStateStubb(),
    APP_CONFIG,
    setTimeout: (fn, delay) => { if (delay === 0) fn(); },
    _exports: exports,
    _panelEl: panelEl,
    _documentMock: documentMock,
  };

  const keys = Object.keys(ctx);
  const vals = keys.map(k => ctx[k]);
  try {
    // eslint-disable-next-line no-new-func
    new Function(...keys, wrapper)(...vals);
  } catch (_) {}

  return { storage, panelEl, documentMock };
}

module.exports = {
  loadConfigModule,
  loadEngineModule,
  loadAppStateModule,
  loadUiHelpersModule,
  loadMultiplayerServiceColorModule,
  loadMultiplayerVotingModule,
  loadSharingModule,
  loadGameStorageModule,
  loadPanelSystemModule,
  makeStateStubb,
  makeDOMStub,
};
