'use strict';

const fs = require('fs');
const path = require('path');

const votingSource = fs.readFileSync(
  path.resolve(__dirname, '../../js/network/multiplayer-voting.js'),
  'utf8'
);

function clone(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

function makeRoom(instanceNumber = 2) {
  return {
    meta: {
      instanceNumber,
      createdAtTimestamp: 1000,
      ownerPlayerId: 'player-1',
      boardDimension: 4
    },
    boardState: {
      boardInstanceNumber: instanceNumber,
      boardValues: [['1', '', '', ''], ['', '2', '', ''], ['', '', '3', ''], ['', '', '', '4']],
      pencilNotes: [],
      elapsedSeconds: 42,
      isCompleted: false,
      updatedAtTimestamp: 2000
    },
    settings: { immediateErrorCheck: true },
    contributions: { '0_1': { kind: 'PLAYER', action: 'SET', playerId: 'player-1' } },
    moves: { move_1: { userId: 'player-1', action: 'SET' } },
    history: {},
    proposal: { proposalId: 'proposal-1', status: 'pending' },
    contributionEvents: { [String(instanceNumber)]: { event_1: { operation: 'SET' } } },
    players: { 'player-1': { playerId: 'player-1', playerName: 'Tester' } }
  };
}

function makeHarness(options = {}) {
  const state = {
    multiplayer: {
      active: true,
      roomId: 'ROOM1',
      playerId: 'player-1',
      playerName: 'Tester',
      instanceCount: 2,
      executingProposalId: null,
      executedProposalId: null
    }
  };
  let room = options.room === undefined ? makeRoom() : clone(options.room);
  const calls = [];
  const toasts = [];
  const errors = [];
  const warnings = [];
  const refs = [];
  const unsubscribeCalls = [];
  let cachedRoom = null;

  const fb = {
    db: {},
    ref(_db, refPath) {
      const ref = { path: refPath };
      refs.push(ref);
      return ref;
    },
    child(parentRef, childName) {
      const ref = { path: `${parentRef.path}/${childName}` };
      refs.push(ref);
      return ref;
    },
    onValue: jest.fn((ref, callback) => {
      calls.push(`onValue:${ref.path}`);
      // A assinatura temporária mantém a raiz completa sincronizada no cache
      // durante a transação. O callback inicial é o snapshot completo da sala.
      cachedRoom = clone(room);
      const unsubscribe = jest.fn(() => calls.push(`unsubscribe:${ref.path}`));
      unsubscribeCalls.push(unsubscribe);
      callback({ val: () => clone(cachedRoom) });
      return unsubscribe;
    }),
    runTransaction: jest.fn((ref, updateFn) => {
      calls.push(`transaction:${ref.path}`);
      const localCandidate = updateFn(clone(cachedRoom));
      if (localCandidate === undefined) return Promise.resolve({ committed: false });
      // Simula uma gravação concorrente depois do snapshot local. O RTDB deve
      // repetir o updater com o valor atual do servidor antes de confirmar.
      if (typeof options.afterRootSnapshot === 'function') room = options.afterRootSnapshot(clone(room));
      if (JSON.stringify(room) !== JSON.stringify(cachedRoom)) {
        const serverCandidate = updateFn(clone(room));
        if (serverCandidate === undefined) return Promise.resolve({ committed: false });
        room = clone(serverCandidate);
      } else {
        room = clone(localCandidate);
      }
      return Promise.resolve({ committed: true, snapshot: { val: () => clone(room) } });
    }),
    update: jest.fn((ref, patch) => {
      calls.push(`update:${ref.path}`);
      if (options.failProposalUpdate) return Promise.reject(new Error('permission-denied'));
      if (ref.path === 'rooms/ROOM1/proposal') room.proposal = { ...room.proposal, ...patch };
      return Promise.resolve();
    }),
    remove: jest.fn(() => Promise.resolve())
  };

  const context = {
    state,
    APP_CONFIG: { MULTIPLAYER_VOTE_TIMEOUT_MS: 45000 },
    getFirebaseAPI: () => fb,
    roomPath: (roomId, childName = '') => `rooms/${roomId}${childName ? '/' + childName : ''}`,
    buildSymbolsFromRange: () => ['1', '2', '3', '4'],
    computeBlockDimensions: () => ({ blockR: 2, blockC: 2 }),
    createUniqueSudokuPuzzle: () => ({
      solution: [['1', '2', '3', '4'], ['3', '4', '1', '2'], ['2', '1', '4', '3'], ['4', '3', '2', '1']],
      initial: [['1', '', '', ''], ['', '2', '', ''], ['', '', '3', ''], ['', '', '', '4']]
    }),
    createRoomMeta: (instanceNumber, ownerPlayerId, overrides) => ({
      instanceNumber,
      ownerPlayerId,
      createdAtTimestamp: 3000,
      boardDimension: 4,
      ...overrides
    }),
    showToast: (message, type) => toasts.push({ message, type }),
    setTimeout: jest.fn(),
    console: {
      error: (...args) => errors.push(args),
      warn: (...args) => warnings.push(args),
      log: jest.fn()
    }
  };

  const keys = Object.keys(context);
  const execute = new Function(...keys, `${votingSource}\nreturn executeMultiplayerNewGame;`)(...keys.map(key => context[key]));
  const proposal = {
    proposalId: 'proposal-1',
    proposerId: 'player-1',
    status: 'pending',
    gameMode: 'custom',
    difficultyLevel: 'medio',
    minimumSymbolValue: 1,
    maximumSymbolValue: 4,
    includesZeroValue: false,
    baseInstanceNumber: 2
  };

  return {
    execute,
    proposal,
    state,
    fb,
    calls,
    unsubscribeCalls,
    toasts,
    errors,
    warnings,
    getRoom: () => room
  };
}

describe('executeMultiplayerNewGame — transição de instância', () => {
  test('mantém a raiz completa em cache durante a transação e publica a nova instância', async () => {
    const h = makeHarness();
    h.execute(h.proposal);
    await new Promise(resolve => setImmediate(resolve));

    expect(h.calls[0]).toBe('onValue:rooms/ROOM1');
    expect(h.calls[1]).toBe('transaction:rooms/ROOM1');
    expect(h.getRoom().meta.instanceNumber).toBe(3);
    expect(h.getRoom().boardState.boardInstanceNumber).toBe(3);
    expect(h.getRoom().history['2'].instanceNumber).toBe(2);
    expect(h.getRoom().history['2'].boardState.elapsedSeconds).toBe(42);
    expect(h.getRoom().history['2'].settings.immediateErrorCheck).toBe(true);
    expect(h.getRoom().history['2'].contributions['0_1'].playerId).toBe('player-1');
    expect(h.getRoom().contributions).toEqual({});
    expect(h.getRoom().moves).toBeNull();
    expect(h.getRoom().contributionEvents).toEqual({ '2': { event_1: { operation: 'SET' } } });
    expect(h.state.multiplayer.instanceCount).toBe(3);
    expect(h.state.multiplayer.executedProposalId).toBe('proposal-1');
    expect(h.fb.update).toHaveBeenCalledTimes(1);
    expect(h.unsubscribeCalls[0]).toHaveBeenCalledTimes(1);
    expect(h.toasts).toHaveLength(0);
  });

  test('não inicia transação quando a leitura completa não encontra a sala', async () => {
    const h = makeHarness({ room: null });
    h.execute(h.proposal);
    await new Promise(resolve => setImmediate(resolve));

    expect(h.fb.onValue).toHaveBeenCalledTimes(1);
    expect(h.fb.runTransaction).not.toHaveBeenCalled();
    expect(h.state.multiplayer.instanceCount).toBe(2);
    expect(h.toasts).toHaveLength(1);
    expect(h.toasts[0].message).toMatch(/não foi possível gravar o novo tabuleiro/i);
  });


  test('usa o estado autoritativo no retry e aborta se a instância mudou desde o snapshot', async () => {
    const h = makeHarness({
      afterRootSnapshot: latestRoom => {
        latestRoom.meta.instanceNumber = 3;
        latestRoom.boardState.boardInstanceNumber = 3;
        return latestRoom;
      }
    });
    h.execute(h.proposal);
    await new Promise(resolve => setImmediate(resolve));

    expect(h.getRoom().meta.instanceNumber).toBe(3);
    expect(h.getRoom().history['2']).toBeUndefined();
    expect(h.state.multiplayer.instanceCount).toBe(2);
    expect(h.fb.update).not.toHaveBeenCalled();
    expect(h.toasts).toHaveLength(1);
  });

  test('aborta sem sobrescrever quando o snapshot histórico da instância já existe', async () => {
    const room = makeRoom();
    room.history['2'] = {
      instanceNumber: 2,
      meta: room.meta,
      boardState: room.boardState,
      archivedAtTimestamp: 2500
    };
    const h = makeHarness({ room });
    h.execute(h.proposal);
    await new Promise(resolve => setImmediate(resolve));

    expect(h.getRoom().meta.instanceNumber).toBe(2);
    expect(h.state.multiplayer.instanceCount).toBe(2);
    expect(h.fb.update).not.toHaveBeenCalled();
    expect(h.toasts).toHaveLength(1);
  });

  test('distingue falha ao finalizar a votação depois de o novo tabuleiro já ter sido gravado', async () => {
    const h = makeHarness({ failProposalUpdate: true });
    h.execute(h.proposal);
    await new Promise(resolve => setImmediate(resolve));

    expect(h.getRoom().meta.instanceNumber).toBe(3);
    expect(h.state.multiplayer.instanceCount).toBe(3);
    expect(h.state.multiplayer.executedProposalId).toBe('proposal-1');
    expect(h.toasts).toHaveLength(1);
    expect(h.toasts[0].message).toMatch(/novo tabuleiro foi gravado/i);
    expect(h.toasts[0].message).not.toMatch(/não foi possível gravar o novo tabuleiro/i);
    expect(h.errors.some(args => String(args[0]).includes('não foi possível finalizar a votação'))).toBe(true);
  });
});
